$(document).ready(function() {
    $('#signupForm').submit(function(e) {
      e.preventDefault();
      var username = $('#username').val();
      var password = $('#password').val();
      // Perform AJAX request to register endpoint
      $.ajax({
        url: '/register',
        method: 'POST',
        data: { username: username, password: password },
        success: function(response) {
          // Handle successful registration
          alert('Registration successful! Please login.');
          window.location.href = '/login.html';
        },
        error: function(error) {
          // Handle registration error
          alert('Registration failed. Please try again.');
        }
      });
    });
  });
  
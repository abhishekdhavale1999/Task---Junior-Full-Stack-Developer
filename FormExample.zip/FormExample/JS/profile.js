$(document).ready(function() {
    // Retrieve and populate user's profile data
    $.ajax({
      url: '/profile',
      method: 'GET',
      success: function(response) {
        // Populate profile fields with response data
        $('#age').val(response.age);
        $('#dob').val(response.dob);
        $('#contact').val(response.contact);
        // Populate more fields with additional details
      },
      error: function(error) {
        // Handle profile retrieval error
        alert('Error retrieving profile data.');
      }
    });
  
    $('#profileForm').submit(function(e) {
      e.preventDefault();
      var age = $('#age').val();
      var dob = $('#dob').val();
      var contact = $('#contact').val();
      // Perform AJAX request to update profile endpoint
      $.ajax({
        url: '/profile',
        method: 'POST',
        data: { age: age, dob: dob, contact: contact },
        success: function(response) {
          // Handle successful profile update
          alert('Profile updated successfully!');
        },
        error: function(error) {
          // Handle profile update error
          alert('Error updating profile. Please try again.');
        }
      });
    });
  });
  
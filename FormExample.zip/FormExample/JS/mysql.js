// mysql.js
import { createConnection } from 'mysql2';


// Create MySQL connection
const connection = createConnection({
  host: 'localhost',
  user: 'your_mysql_username',
  password: 'your_mysql_password',
  database: 'your_database_name'
});

// Registration function
function registerUser(username, email, password) {
  return new Promise((resolve, reject) => {
    const sql = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
    const values = [username, email, password];

    connection.query(sql, values, (error, results) => {
      if (error) {
        reject(error);
      } else {
        resolve(results.insertId);
      }
    });
  });
}

// Login function
function loginUser(username, password) {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT id FROM users WHERE username = ? AND password = ?';
    const values = [username, password];

    connection.query(sql, values, (error, results) => {
      if (error) {
        reject(error);
      } else {
        if (results.length > 0) {
          resolve(results[0].id);
        } else {
          resolve(null);
        }
      }
    });
  });
}

export default {
  registerUser,
  loginUser
};

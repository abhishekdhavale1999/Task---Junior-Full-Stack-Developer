// mongodb.js
const mongoose = require('mongoose');
const mongodbConfig = require('./mongodbConfig.json');

// Create MongoDB connection
mongoose.connect(`${mongodbConfig.url}/${mongodbConfig.database}`, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Rest of the code...

module.exports = {
  saveProfile,
  getProfile
};

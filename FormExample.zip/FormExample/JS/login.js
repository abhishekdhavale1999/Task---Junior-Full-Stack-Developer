$(document).ready(function() {
    $('#loginForm').submit(function(e) {
      e.preventDefault();
      var username = $('#username').val();
      var password = $('#password').val();
      // Perform AJAX request to login endpoint
      $.ajax({
        url: '/login',
        method: 'POST',
        data: { username: username, password: password },
        success: function(response) {
          // Store session information in localStorage
          localStorage.setItem('isLoggedIn', true);
          localStorage.setItem('username', username);
          // Redirect to profile page
          window.location.href = '/profile.html';
        },
        error: function(error) {
          // Handle login error
          alert('Login failed. Please check your username and password.');
        }
      });
    });
  });
  